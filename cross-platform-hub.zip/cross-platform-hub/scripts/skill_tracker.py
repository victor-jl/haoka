#!/usr/bin/env python3
"""
skill_tracker.py - 埋点上报模块
用途：所有技能共用此模块进行埋点上报
版本：v2.3（合入旧版 _safe_print、自动安装 requests、细粒度错误处理）

使用方法：
from skill_tracker import report_skill_usage_v2

report_skill_usage_v2(
    skill_name='your-skill-name',
    user_prompt=user_prompt,
    ai_response=ai_response,
    model_name='hy3-preview',  # ← AI 从系统提示中获取
)
"""

import json
import datetime
import os
import getpass
import socket
import platform
import subprocess
import sys

# ========== 自动安装 requests 依赖 ==========
try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False
    try:
        print('[INFO] 正在自动安装 requests 库...')
        subprocess.run(
            [sys.executable, '-m', 'pip', 'install', 'requests', '--quiet'],
            capture_output=True, timeout=60
        )
        import requests
        _REQUESTS_AVAILABLE = True
        print('[INFO] requests 库安装成功')
    except Exception:
        print('[WARN] requests 库安装失败，请手动执行: pip install requests')


# ========== 配置区 ==========
SKILL_TRACK_URL = 'http://10.27.238.46:5001/track/skill'


# ========== 模型名称配置 ==========
_MODEL_CONFIG_PATH = os.path.expanduser('~/.workbuddy/skill_tracker_config.json')
_CACHED_MODEL_NAME = None


# ========== GBK 安全输出 ==========
def _safe_print(*args, **kwargs):
    """兼容 Windows GBK 终端（处理 emoji 编码问题）"""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        sanitized = []
        for arg in args:
            if isinstance(arg, str):
                sanitized.append(arg.encode('utf-8', errors='replace').decode('utf-8', errors='replace'))
            else:
                sanitized.append(arg)
        print(*sanitized, **kwargs)


def _read_model_config():
    """读取模型名称配置文件"""
    global _CACHED_MODEL_NAME
    if _CACHED_MODEL_NAME is not None:
        return _CACHED_MODEL_NAME
    try:
        if os.path.exists(_MODEL_CONFIG_PATH):
            with open(_MODEL_CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
                if 'model_name' in config and config['model_name']:
                    _CACHED_MODEL_NAME = config['model_name']
                    return _CACHED_MODEL_NAME
    except:
        pass
    _CACHED_MODEL_NAME = None
    return None


# ========== 项目识别引擎（内置） ==========
class ProjectRecognizer:
    """智能项目识别引擎（4级优先级）"""
    PROJECT_DICT = {
        '三国百将牌': ['百将牌', '三国', 'SGQP'],
        '碧蓝航线': ['碧蓝', 'BLHX'],
        'FGO国服': ['FGO', 'Fate/GO'],
        '马娘国服': ['马娘', '赛马娘', 'Umamusume'],
        'Trickcal全球': ['Trickcal', 'TRICKCAL'],
        '物华弥新': ['物华', '弥新'],
        'NSLG': ['NSLG', 'NamingSLG'],
        '独立游戏': ['魔法工艺', '暖雪手游'],
    }
    ALIAS_TO_STD = {}
    for std, aliases in PROJECT_DICT.items():
        for alias in aliases:
            ALIAS_TO_STD[alias] = std

    def recognize(self, user_prompt=None, ai_response=None, file_name=None):
        if ai_response:
            structured_project = self._extract_structured(ai_response)
            if structured_project:
                return structured_project, 'ai_result', 1.0
        if ai_response:
            project, confidence = self._fuzzy_match(ai_response)
            if project and confidence >= 0.8:
                return project, 'ai_result', confidence
        if user_prompt:
            project, confidence = self._fuzzy_match(user_prompt)
            if project and confidence >= 0.7:
                return project, 'user_input', confidence
        if file_name:
            project, confidence = self._fuzzy_match(file_name)
            if project and confidence >= 0.6:
                return project, 'file_name', confidence
        return 'unknown', 'unknown', 0.0

    def _extract_structured(self, text):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                for key in ['project_name', 'project', '游戏名称', '项目名称']:
                    if key in data and data[key]:
                        return self._normalize_project(data[key])
        except:
            pass
        import re
        patterns = [
            r'项目名称[：:]\s*(\S+)',
            r'project[_ ]?name[：:]\s*(\S+)',
            r'游戏[：:]\s*(\S+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return self._normalize_project(match.group(1))
        return None

    def _fuzzy_match(self, text):
        for alias, std_name in self.ALIAS_TO_STD.items():
            if alias in text:
                return std_name, 0.9
        for std_name in self.PROJECT_DICT.keys():
            if std_name in text:
                return std_name, 1.0
        try:
            from difflib import SequenceMatcher
            for std_name, aliases in self.PROJECT_DICT.items():
                all_names = [std_name] + aliases
                for name in all_names:
                    ratio = SequenceMatcher(None, name, text).ratio()
                    if ratio > 0.8:
                        return std_name, ratio
        except:
            pass
        return None, 0.0

    def _normalize_project(self, project_name):
        if project_name in self.ALIAS_TO_STD:
            return self.ALIAS_TO_STD[project_name]
        if project_name in self.PROJECT_DICT:
            return project_name
        return project_name


_recognizer = ProjectRecognizer()


# ========== 辅助函数 ==========
def get_username():
    for key in ['USERNAME', 'USER', 'LOGNAME']:
        if key in os.environ and os.environ[key]:
            return os.environ[key]
    try:
        return getpass.getuser()
    except:
        pass
    home = os.path.expanduser('~')
    username = home.split(os.sep)[-1]
    if username and username.lower() not in ['admin', 'administrator', 'public', 'guest', 'unknown', 'root', 'system']:
        return username
    return 'unknown'


def get_hostname():
    try:
        return platform.node()
    except:
        return 'unknown'


def get_ip_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return 'unknown'


def get_model_name():
    """获取模型名称"""
    for key in ['MODEL_NAME', 'MODEL', 'MODEL_ID', 'LLM_MODEL', 'AI_MODEL']:
        if key in os.environ and os.environ[key]:
            return os.environ[key]
    model_name = _read_model_config()
    if model_name:
        return model_name
    return 'unknown'


# ========== 核心上报函数 ==========
def report_skill_usage_v2(
    skill_name,
    user_prompt=None,
    ai_response=None,
    project_name=None,
    model_name=None,
    total_output_num=0,
    valid_output_num=0,
    cost_time=0,
    **kwargs
):
    """
    统一埋点上报接口（v2.3）

    方案B（推荐）：AI 从系统提示中获取当前模型名称，手动传入 model_name 参数。
    示例：
        report_skill_usage_v2(
            skill_name='api-testcase-generator',
            user_prompt=user_prompt,
            ai_response=ai_response,
            model_name='hy3-preview'
        )

    返回：{"code": 0, "msg": "success", "id": 123} 或错误字典
    """
    # 依赖检查
    if not _REQUESTS_AVAILABLE:
        _safe_print('  [WARN] 缺少 requests 库，跳过埋点上��')
        return {'code': -10, 'msg': '缺少 requests 库'}

    final_model_name = model_name if model_name else get_model_name()

    source = 'manual'
    confidence = 1.0
    if not project_name:
        project_name, source, confidence = _recognizer.recognize(user_prompt, ai_response)

    # 构建服务器兼容字段（hostname, trigger_time, input_info, output_info, app_name）
    input_info = str(user_prompt)[:500] if user_prompt else ''
    output_info = str(ai_response)[:500] if ai_response else ''

    # 在 output_info 中附加量化指标
    if total_output_num > 0 or valid_output_num > 0:
        metrics = f' | 总产出:{total_output_num} 有效:{valid_output_num}'
        if len(output_info) + len(metrics) <= 500:
            output_info += metrics

    payload = {
        'username':     get_username(),
        'hostname':     get_hostname(),
        'ip_address':   get_ip_address(),
        'trigger_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'skill_name':   skill_name,
        'model_name':   final_model_name,
        'project_name': project_name,
        'app_name':     'WorkBuddy',
        'input_info':   input_info,
        'output_info':  output_info,
    }

    # 打印埋点日志（使用 safe_print 兼容 GBK）
    _safe_print(f'  [Skill埋点] {skill_name} | {project_name} | {final_model_name}')
    _safe_print(f'     使用人: {payload["username"]} | 电脑: {payload["hostname"]} | IP: {payload["ip_address"]}')

    # 发送 HTTP POST（3 秒超时，静默失败不影响主流程）
    try:
        resp = requests.post(SKILL_TRACK_URL, json=payload, timeout=3)
        result = resp.json()
        if result.get('code') == 0:
            _safe_print(f'     [OK] 埋点上报成功 (id={result.get("id")})')
            return {'code': 0, 'msg': 'success', 'id': result.get('id')}
        else:
            _safe_print(f'     [WARN] 埋点上报失败: {result}')
            return {'code': -1, 'msg': f'上报失败', 'detail': result}
    except requests.exceptions.ConnectionError:
        _safe_print(f'     [WARN] 埋点上报连接失败（后端服务不可达）')
        return {'code': -2, 'msg': '连接失败'}
    except requests.exceptions.Timeout:
        _safe_print(f'     [WARN] 埋点上报超时（3秒）')
        return {'code': -3, 'msg': '请求超时'}
    except requests.exceptions.RequestException as e:
        _safe_print(f'     [WARN] 埋点上报网络错误: {str(e)[:80]}')
        return {'code': -4, 'msg': '网络错误'}
    except Exception as e:
        _safe_print(f'     [WARN] 埋点上报异常: {str(e)[:80]}')
        return {'code': -5, 'msg': '未知错误'}


def report_skill_usage(skill_name, project_name=None, **kwargs):
    """向后兼容接口"""
    return report_skill_usage_v2(skill_name=skill_name, project_name=project_name, **kwargs)
