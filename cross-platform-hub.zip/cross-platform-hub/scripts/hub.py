#!/usr/bin/env python3
"""
跨平台 Agent/Skill 互通中心
扫描 Cursor(.qoder) / Trae(.trae) / WorkBuddy(.workbuddy) 的所有 agent 和 skill，
支持读取、转换、复制到其他平台。
"""
import os, json, yaml, shutil, sys, re
from pathlib import Path
from datetime import datetime

HOME = Path.home()

# ====== 平台扫描路径 ======
PLATFORMS = {
    "workbuddy": {
        "skills": [HOME / ".workbuddy" / "skills"],
        "agents": [HOME / ".workbuddy" / "agents"],
        "experts": [
            HOME / ".workbuddy" / "plugins" / "marketplaces" / "my-experts",
            HOME / ".workbuddy" / "plugins" / "marketplaces" / "experts",
        ],
        "identity": [HOME / ".workbuddy" / "IDENTITY.md"],
    },
    "cursor": {
        "skills": [HOME / ".qoder" / "skills"],
        "agents": [HOME / ".qoder" / "agents"],
        "knowledge": [HOME / ".qoder" / "knowledges"],
    },
    "trae": {
        "skills": [],  # 项目级
        "agents": [],
    },
}

# 项目级追加
def add_project_paths():
    cwd = Path.cwd()
    PLATFORMS["cursor"]["skills"].append(cwd / ".qoder" / "skills")
    PLATFORMS["cursor"]["agents"].append(cwd / ".qoder" / "agents")
    PLATFORMS["cursor"]["knowledge"].append(cwd / ".qoder" / "knowledge")
    PLATFORMS["trae"]["skills"].append(cwd / ".trae" / "skills")
    PLATFORMS["trae"]["agents"].append(cwd / ".trae" / "agents")
    PLATFORMS["workbuddy"]["skills"].append(cwd / ".workbuddy" / "skills")
    PLATFORMS["workbuddy"]["agents"].append(cwd / ".workbuddy" / "agents")


def scan_skills(base_dirs):
    """扫描目录中的 skill（找 SKILL.md）"""
    items = []
    for base in base_dirs:
        if not base.exists():
            continue
        for entry in base.iterdir():
            if entry.is_symlink() or entry.is_dir():
                target = entry.resolve() if entry.is_symlink() else entry
                skill_md = target / "SKILL.md" if target.is_dir() else None
                if skill_md and skill_md.exists():
                    items.append({
                        "name": entry.name,
                        "path": str(target),
                        "type": "symlink" if entry.is_symlink() else "directory",
                        "definition": str(skill_md),
                    })
                # 也检查 .skill 打包文件
            elif entry.suffix == ".skill" or entry.suffix == ".zip":
                items.append({
                    "name": entry.stem,
                    "path": str(entry),
                    "type": "archive",
                    "definition": str(entry),
                })
    return items


def scan_agents(base_dirs):
    """扫描 agent 定义"""
    items = []
    for base in base_dirs:
        if not base.exists():
            continue
        for entry in base.iterdir():
            if entry.is_dir():
                agent_md = entry / "agent.md" if (entry / "agent.md").exists() else (
                    entry / "SKILL.md" if (entry / "SKILL.md").exists() else None
                )
                if agent_md:
                    items.append({
                        "name": entry.name,
                        "path": str(entry),
                        "definition": str(agent_md),
                        "has_config": (entry / "plugin.json").exists(),
                    })
            elif entry.suffix == ".md":
                items.append({
                    "name": entry.stem,
                    "path": str(entry),
                    "definition": str(entry),
                    "type": "standalone",
                })
    return items


def scan_experts(base_dirs):
    """扫描 WorkBuddy expert 包"""
    items = []
    for base in base_dirs:
        if not base.exists():
            continue
        for entry in base.iterdir():
            if entry.is_dir():
                plugin_json = entry / "plugin.json"
                agent_dir = entry / "agents"
                if plugin_json.exists():
                    try:
                        cfg = json.loads(plugin_json.read_text())
                        items.append({
                            "name": entry.name,
                            "path": str(entry),
                            "display": cfg.get("name", entry.name),
                            "description": cfg.get("description", ""),
                            "agents": list(agent_dir.glob("*.md")) if agent_dir.exists() else [],
                            "has_avatar": (entry / "expert.png").exists(),
                        })
                    except:
                        pass
                elif agent_dir.exists():
                    for amd in agent_dir.glob("*.md"):
                        items.append({
                            "name": f"{entry.name}/{amd.stem}",
                            "path": str(amd),
                            "definition": str(amd),
                        })
    return items


def read_skill_metadata(skill_path):
    """读取 SKILL.md 的 YAML frontmatter"""
    path = Path(skill_path)
    if not path.exists():
        return {}
    content = path.read_text(encoding="utf-8", errors="ignore")
    m = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
    if m:
        try:
            return yaml.safe_load(m.group(1)) or {}
        except:
            pass
    return {}


def convert_skill(source_path, source_platform, target_platform, target_dir, dry_run=False):
    """
    将 skill 从源平台格式转换为目标平台格式
    目前所有平台共用 SKILL.md 格式，主要是路径适配
    """
    source = Path(source_path)
    target = Path(target_dir) / source.name

    if dry_run:
        return {"action": "copy", "from": str(source), "to": str(target), "dry_run": True}

    if target.exists():
        return {"action": "skip", "reason": f"目标已存在: {target}"}

    if source.is_dir():
        shutil.copytree(source, target, symlinks=True)
    else:
        shutil.copy2(source, target)

    return {"action": "copied", "from": str(source), "to": str(target)}


# ====== CLI ======
def cmd_list(args):
    """列出所有平台的 agent/skill"""
    add_project_paths()

    print("=" * 70)
    print("🤖 跨平台 Agent / Skill / Expert 一览")
    print("=" * 70)

    for platform, paths in PLATFORMS.items():
        print(f"\n### {platform.upper()} ###")

        # Skills
        skills = scan_skills(paths.get("skills", []))
        if skills:
            print(f"  📦 Skills ({len(skills)}):")
            for s in skills:
                meta = read_skill_metadata(s["definition"])
                desc = meta.get("description", "")[:60]
                print(f"    {s['name']:<30} [{s['type']}] {desc}")

        # Agents
        agents = scan_agents(paths.get("agents", []))
        if agents:
            print(f"  🤖 Agents ({len(agents)}):")
            for a in agents:
                print(f"    {a['name']:<30} {'📄' if a.get('has_config') else '📝'} {a.get('type','')}")

        # Experts
        experts = scan_experts(paths.get("experts", []))
        if experts:
            print(f"  🧠 Experts ({len(experts)}):")
            for e in experts:
                agents_list = [p.stem for p in e.get("agents", [])]
                print(f"    {e['name']:<30} {e.get('display','')} agents:{agents_list}")


def cmd_read(args):
    """读取指定 skill/agent 的完整内容"""
    add_project_paths()

    name = args[0] if args else None
    if not name:
        print("用法: hub.py read <name>")
        return

    # 在所有平台搜索
    for platform, paths in PLATFORMS.items():
        for skill in scan_skills(paths.get("skills", [])):
            if skill["name"] == name or name in skill["name"]:
                print(f"\n{'='*70}")
                print(f"📦 Skill: {skill['name']} [{platform}]")
                print(f"   路径: {skill['path']}")
                print(f"   类型: {skill['type']}")
                content = Path(skill["definition"]).read_text(encoding="utf-8", errors="ignore")
                print(f"{'='*70}")
                print(content[:3000])
                if len(content) > 3000:
                    print(f"\n... (共 {len(content)} 字符，已截断)")
                return

        for agent in scan_agents(paths.get("agents", [])):
            if agent["name"] == name or name in agent["name"]:
                print(f"\n{'='*70}")
                print(f"🤖 Agent: {agent['name']} [{platform}]")
                content = Path(agent["definition"]).read_text(encoding="utf-8", errors="ignore")
                print(f"{'='*70}")
                print(content[:3000])
                if len(content) > 3000:
                    print(f"\n... (共 {len(content)} 字符，已截断)")
                return

        for expert in scan_experts(paths.get("experts", [])):
            if expert["name"] == name or name in expert["name"]:
                print(f"\n{'='*70}")
                print(f"🧠 Expert: {expert['name']} [{platform}]")
                print(f"   {json.dumps({k:v for k,v in expert.items() if k != 'agents'}, ensure_ascii=False, indent=2)}")
                return

    print(f"❌ 未找到: {name}")


def cmd_copy(args):
    """复制 skill/agent 到指定平台"""
    if len(args) < 2:
        print("用法: hub.py copy <name> <target_platform>")
        print("目标平台: workbuddy | cursor | trae")
        return

    name, target = args[0], args[1]
    add_project_paths()

    # 查找源
    source_path = None
    source_platform = None
    for platform, paths in PLATFORMS.items():
        for skill in scan_skills(paths.get("skills", [])):
            if skill["name"] == name:
                source_path = skill["path"]
                source_platform = platform
                break
        if source_path:
            break
        for agent in scan_agents(paths.get("agents", [])):
            if agent["name"] == name:
                source_path = agent["path"]
                source_platform = platform
                break
        if source_path:
            break

    if not source_path:
        print(f"❌ 未找到: {name}")
        return

    # 确定目标目录
    target_map = {
        "workbuddy": HOME / ".workbuddy" / "skills",
        "cursor": HOME / ".qoder" / "skills",
        "trae": Path.cwd() / ".trae" / "skills",
    }
    target_dir = target_map.get(target)
    if not target_dir:
        print(f"❌ 未知目标平台: {target}")
        return

    result = convert_skill(source_path, source_platform, target, target_dir)
    print(f"✅ {result['action']}: {source_path} → {target_dir}/{Path(source_path).name}")


def cmd_search(args):
    """模糊搜索 agent/skill"""
    keyword = args[0] if args else ""
    add_project_paths()

    print(f"🔍 搜索: '{keyword}'")
    found = []

    for platform, paths in PLATFORMS.items():
        for skill in scan_skills(paths.get("skills", [])):
            meta = read_skill_metadata(skill["definition"])
            desc = meta.get("description", "")
            if keyword.lower() in skill["name"].lower() or keyword.lower() in desc.lower():
                found.append((platform, "skill", skill["name"], desc[:80]))

        for agent in scan_agents(paths.get("agents", [])):
            if keyword.lower() in agent["name"].lower():
                found.append((platform, "agent", agent["name"], ""))

        for expert in scan_experts(paths.get("experts", [])):
            desc = expert.get("description", "")
            if keyword.lower() in expert["name"].lower() or keyword.lower() in desc.lower():
                found.append((platform, "expert", expert["name"], desc[:80]))

    if not found:
        print("  无结果")
        return

    for plat, typ, name, desc in found:
        icon = {"skill": "📦", "agent": "🤖", "expert": "🧠"}.get(typ, "📄")
        print(f"  {icon} [{plat}] {name:<30} {desc}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("跨平台 Agent/Skill 互通中心")
        print("用法:")
        print("  python hub.py list              # 列出所有")
        print("  python hub.py read <name>       # 读取指定 skill")
        print("  python hub.py copy <name> <to>  # 复制到指定平台")
        print("  python hub.py search <kw>       # 模糊搜索")
        sys.exit(0)

    cmd = sys.argv[1]
    args = sys.argv[2:]

    if cmd == "list": cmd_list(args)
    elif cmd == "read": cmd_read(args)
    elif cmd == "copy": cmd_copy(args)
    elif cmd == "search": cmd_search(args)
    else:
        print(f"未知命令: {cmd}")
