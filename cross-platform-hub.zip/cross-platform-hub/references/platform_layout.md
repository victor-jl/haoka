# 三平台 Agent/Skill 完整布局

## WorkBuddy（~/.workbuddy/）

```
~/.workbuddy/
├── skills/                          # 28 个 skills（含 2 个 symlink→~/.agents/）
│   ├── SKILL.md (各含)              # 核心定义文件
│   ├── scripts/                     # Python/Bash 脚本
│   ├── references/                  # 参考文档
│   └── *.skill / *.zip              # 打包归档
├── agents/                          # 自定义 agent 定义
├── plugins/marketplaces/
│   ├── my-experts/                  # 3 个自定义 expert 包
│   │   ├── code-knowledge-architect/
│   │   │   ├── plugin.json
│   │   │   └── agents/code-knowledge-architect.md
│   │   ├── lingmou/
│   │   └── senior-test-engineer/
│   └── experts/                     # webapp-testing expert
├── experts/custom/<uuid>/experts.json
├── SOUL.md / IDENTITY.md / USER.md  # 身份定义
└── mcp.json                         # MCP 连接器配置
```

### Skill 标准结构
```
skill-name/
├── SKILL.md          # 必需：YAML frontmatter + Markdown 指令
├── scripts/          # 可执行脚本
├── references/       # 参考文档（按需加载）
└── assets/           # 模板/资源文件
```

## Cursor（~/.qoder/）

```
~/.qoder/
├── skills/                          # 3 个 skills（均为 symlink→~/.agents/）
│   ├── browser-use → ~/.agents/skills/browser-use
│   ├── cdp → ~/.agents/skills/cdp
│   └── ego-browser → ~/.agents/skills/ego-browser
├── knowledges/                      # 知识库条目
├── plugins/                         # Cursor 插件
├── extensions/                      # VS Code 扩展
├── memories/                        # 记忆
└── settings.json
```

### 项目级 .qoder/
```
project/.qoder/
├── repowiki/                        # RepoWiki（代码知识蒸馏）
│   ├── wiki_plan.yaml              # 生成配置
│   ├── FLYWHEEL_GUIDE.md           # 飞轮更新指南
│   └── zh/                         # 中文 Wiki
│       ├── modules/                # 模块文档
│       ├── content/                # 详细内容
│       └── knowledge-cards/        # Agent 用知识卡片
└── knowledge/zh/                   # 14 个技术知识条目
```

## Trae（.trae/）

```
project/.trae/
├── skills/
│   ├── TRAE-code-review/
│   │   └── SKILL.md               # 代码审查技能
│   └── TRAE-code-review.zip       # 打包归档
└── agents/                         # Agent 定义（如有）
```

## 共享仓库（~/.agents/）

```
~/.agents/
├── skills/                         # 35 个 skills（Cursor + WorkBuddy 共享）
│   ├── browser-use/               # 通用
│   ├── cdp/
│   ├── clone-website/
│   ├── ego-browser/
│   ├── find-skills/
│   └── dbs*/                       # 30 个 dbs 工具箱 skills
├── .skill-lock.json               # 版本锁定
└── _agents.mount_config
```

## 互操作指南

### 从 Cursor 读取 → WorkBuddy 使用
```bash
# Cursor skill 路径（symlink）
~/.qoder/skills/<name>/SKILL.md
# 实际内容在
~/.agents/skills/<name>/SKILL.md
# 已可通过 WorkBuddy 的 ~/.workbuddy/skills/ 同名 symlink 直接访问
```

### 从 Trae 读取 → WorkBuddy 使用
```bash
# 复制到 WorkBuddy
cp -r .trae/skills/<name> ~/.workbuddy/skills/
```

### 从 WorkBuddy 读取 → 其他平台使用
```bash
# 创建 symlink（推荐）
ln -s ~/.workbuddy/skills/<name> ~/.qoder/skills/<name>
# 或复制
cp -r ~/.workbuddy/skills/<name> .trae/skills/
```

### Expert → Skill 转换
WorkBuddy expert 包含 plugin.json + agent.md，提取 agent.md 即是一个 skill：
```bash
cp ~/.workbuddy/plugins/marketplaces/my-experts/<name>/agents/<agent>.md \
   ~/.workbuddy/skills/<name>/SKILL.md
```
