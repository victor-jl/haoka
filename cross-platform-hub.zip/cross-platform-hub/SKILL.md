---
name: cross-platform-hub
description: 跨平台 Agent/Skill 互通中心。扫描并读取 Cursor(.qoder)、Trae(.trae)、WorkBuddy(.workbuddy) 三平台的所有 agent、skill、expert 定义文件，并支持跨平台复制迁移。触发：跨平台读取 skill、互通 agent、复制技能到其他平台、列出所有平台的 agent、扫描 .qoder .trae .workbuddy 中的技能、平台间迁移 skill。
---

# 跨平台 Agent/Skill 互通中心

三平台（Cursor / Trae / WorkBuddy）的所有 agent、skill、expert 统一扫描和互操作。

## 快速使用

```bash
python scripts/hub.py list              # 列出三平台所有 skill/agent/expert
python scripts/hub.py read <name>       # 读取指定 skill 完整内容
python scripts/hub.py search <keyword>  # 模糊搜索
python scripts/hub.py copy <name> <to>  # 复制到其他平台
```

## 三平台路径映射

| 平台 | 用户级路径 | 项目级路径 | 共享仓库 |
|------|-----------|-----------|---------|
| **WorkBuddy** | `~/.workbuddy/skills/`、`~/.workbuddy/agents/`、`~/.workbuddy/plugins/marketplaces/` | `.workbuddy/skills/` | `~/.agents/` |
| **Cursor** | `~/.qoder/skills/`（多为 symlink→`~/.agents/`） | `.qoder/skills/`、`.qoder/knowledge/` | `~/.agents/` |
| **Trae** | 无 | `.trae/skills/`、`.trae/agents/` | 无 |

> **共享仓库 `~/.agents/skills/`** 是 Cursor 和 WorkBuddy 的桥梁 — 两层都通过 symlink 指向这里，35 个 skills 天然互通。

## AI 代理用法（无需脚本）

在对话中直接执行以下操作：

### 列出所有 skill/agent

跨三平台搜索：

```
~/.workbuddy/skills/      # 28 个 WorkBuddy skills
~/.qoder/skills/           # Cursor skills (symlink→~/.agents/)
~/.agents/skills/          # 共享仓库 35 个 skills
.trae/skills/              # 项目级 Trae skills
~/.workbuddy/plugins/marketplaces/my-experts/  # 自定义 experts
```

### 读取任意平台的 skill

直接 `cat` 对应路径的 `SKILL.md` 或 `agent.md`，提取 YAML frontmatter 获取元数据。

### 跨平台复制

```
cp -r 源平台路径/skill-name 目标平台路径/
```

## Skill 格式对比

三平台均使用 `SKILL.md`（Markdown + YAML frontmatter）作为核心定义，天然兼容：

```yaml
---
name: skill-name
description: 描述（触发依据）
---
# 正文（AI 指令）
```

WorkBuddy 额外支持 `plugin.json` 用于 expert 包注册，Trae 使用 `.zip` 归档。

## 当前已发现

- **Skills**: 67 个（含重复/共享，去重后约 50 个独特 skill）
- **Experts**: 6 个 WorkBuddy 自定义 expert
- **Agents**: boss-skills 下的角色模拟体系
- **Knowledge**: Cursor .qoder 的 repowiki + knowledge 卡片
